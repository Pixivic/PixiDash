import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

final class PackApk {
    public static void main(String[] args) throws IOException {
        try (ZipFile linked = new ZipFile(args[0]);
             ZipOutputStream apk = new ZipOutputStream(
                 new BufferedOutputStream(Files.newOutputStream(Paths.get(args[2]))))) {
            Enumeration<? extends ZipEntry> entries = linked.entries();
            byte[] buffer = new byte[8192];
            while (entries.hasMoreElements()) {
                ZipEntry original = entries.nextElement();
                ZipEntry entry = new ZipEntry(original.getName().replace('\\', '/'));
                if (original.getMethod() == ZipEntry.STORED) {
                    entry.setMethod(ZipEntry.STORED);
                    entry.setSize(original.getSize());
                    entry.setCompressedSize(original.getSize());
                    entry.setCrc(original.getCrc());
                }
                apk.putNextEntry(entry);
                try (InputStream file = linked.getInputStream(original)) {
                    int count;
                    while ((count = file.read(buffer)) != -1) apk.write(buffer, 0, count);
                }
                apk.closeEntry();
            }
            apk.putNextEntry(new ZipEntry("classes.dex"));
            Files.copy(Paths.get(args[1]), apk);
            apk.closeEntry();
        }
    }
}
