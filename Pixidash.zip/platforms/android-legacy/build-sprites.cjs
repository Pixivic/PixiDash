"use strict";

const fs = require("node:fs");
const path = require("node:path");
const source = path.resolve(__dirname, "../../sprites.js");
require(source);

const sheets = Object.entries(globalThis.PixiSprites.frames);
const chunks = [];
function integer(value) {
  const bytes = Buffer.alloc(4);
  bytes.writeInt32BE(value);
  chunks.push(bytes);
}

integer(sheets.length);
for (const [sheet, frames] of sheets) {
  const name = Buffer.from(sheet, "ascii");
  const length = Buffer.alloc(2);
  length.writeUInt16BE(name.length);
  chunks.push(length, name);
  integer(frames.length);
  for (const frame of frames) {
    const { width, height, sx, sy, left, top, maskWidth, maskHeight, mask } = frame;
    for (const value of [width, height, sx, sy, left, top, maskWidth, maskHeight, mask.length]) integer(value);
    chunks.push(Buffer.from(mask));
  }
}
fs.writeFileSync(process.argv[2], Buffer.concat(chunks));