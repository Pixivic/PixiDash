param(
    [string]$AndroidSdk = $env:ANDROID_HOME,
    [string]$JavaHome = $env:JAVA_HOME,
    [string]$Output = (Join-Path $PSScriptRoot '../../release'),
    [string]$Keystore
)

$ErrorActionPreference = 'Stop'
if (!$AndroidSdk) { $AndroidSdk = $env:ANDROID_SDK_ROOT }
if (!$AndroidSdk) { $AndroidSdk = Join-Path $env:LOCALAPPDATA 'Android/Sdk' }
if (!$JavaHome) { $JavaHome = Join-Path $env:ProgramFiles 'Android/Android Studio/jbr' }

$project = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$original = Join-Path $project 'Pixidash assets'
$out = [IO.Path]::GetFullPath($Output)
$work = Join-Path ([IO.Path]::GetTempPath()) ('PixiDash-Legacy-' + [Guid]::NewGuid().ToString('N'))
$assets = Join-Path $work 'assets'
$art = Join-Path $assets 'art'
$packer = Join-Path $work 'packer'
$fonts = Join-Path $assets 'fonts'
$classes = Join-Path $work 'classes'
$dex = Join-Path $work 'dex'
New-Item -ItemType Directory -Path $out,$art,$packer,$fonts,$classes,$dex -Force | Out-Null

function Invoke-Tool([string]$Tool, [string[]]$Arguments) {
    & $Tool @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Tool exited with status $LASTEXITCODE." }
}

try {
    Get-ChildItem -LiteralPath $original -File -Filter '*.png' |
        Where-Object Name -ne 'PixiDash-Arcade-Logo-1x.png' | Copy-Item -Destination $art
    Copy-Item -LiteralPath (Join-Path $original 'Backgrounds') -Destination $art -Recurse
    Copy-Item -LiteralPath (Join-Path $original 'audio') -Destination $assets -Recurse
    Copy-Item -LiteralPath (Join-Path $original 'fonts/Pix32.ttf') -Destination $fonts
    Invoke-Tool 'node' @((Join-Path $PSScriptRoot 'build-sprites.cjs'),(Join-Path $assets 'sprite-frames.dat'))

    $java = Join-Path $JavaHome 'bin/java.exe'
    $javac = Join-Path $JavaHome 'bin/javac.exe'
    $keytool = Join-Path $JavaHome 'bin/keytool.exe'
    $androidJar = Join-Path $AndroidSdk 'platforms/android-35/android.jar'
    $tools = Join-Path $AndroidSdk 'build-tools/35.0.1'
    $linked = Join-Path $work 'linked.apk'
    $unsigned = Join-Path $work 'unsigned.apk'
    $aligned = Join-Path $work 'aligned.apk'
    $apk = Join-Path $out 'PixiDash-Android-Legacy.apk'

    $sources = Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'src') -Filter '*.java' -File -Recurse |
        Select-Object -ExpandProperty FullName
    Invoke-Tool $javac (@('--release','8','-classpath',$androidJar,'-d',$classes) + $sources)
    $classFiles = Get-ChildItem -LiteralPath $classes -Recurse -Filter '*.class' -File | Select-Object -ExpandProperty FullName
    Invoke-Tool $java (@('-cp',(Join-Path $tools 'lib/d8.jar'),'com.android.tools.r8.D8',
        '--lib',$androidJar,'--min-api','16','--output',$dex) + $classFiles)

    $aapt = Join-Path $tools 'aapt2.exe'
    $resources = Join-Path $work 'resources.zip'
    Invoke-Tool $aapt @('compile','--dir',(Join-Path $PSScriptRoot 'res'),'-o',$resources)
    Invoke-Tool $aapt @('link','-o',$linked,'-I',$androidJar,
        '--manifest',(Join-Path $PSScriptRoot 'AndroidManifest.xml'),'-A',$assets,
        '-0','mp3','-0','wav','-0','WAV',$resources)

    Invoke-Tool $javac @('-d',$packer,(Join-Path $PSScriptRoot 'tools/PackApk.java'))
    Invoke-Tool $java @('-cp',$packer,'PackApk',$linked,(Join-Path $dex 'classes.dex'),$unsigned)
    Invoke-Tool (Join-Path $tools 'zipalign.exe') @('-f','4',$unsigned,$aligned)

    $signing = @()
    if (!$Keystore) {
        $signingDir = Join-Path $PSScriptRoot '.signing'
        New-Item -ItemType Directory -Path $signingDir -Force | Out-Null
        $Keystore = Join-Path $signingDir 'sideload.p12'
        if (!(Test-Path -LiteralPath $Keystore)) {
            Invoke-Tool $keytool @('-genkeypair','-keystore',$Keystore,'-storetype','PKCS12',
                '-storepass','android','-keypass','android','-alias','pixidash-legacy',
                '-keyalg','RSA','-keysize','2048','-sigalg','SHA256withRSA','-validity','10000','-dname','CN=PixiDash Legacy')
        }
        $signing = @('--ks-pass','pass:android','--key-pass','pass:android','--ks-key-alias','pixidash-legacy')
    }
    $signer = Join-Path $tools 'lib/apksigner.jar'
    Invoke-Tool $java (@('-jar',$signer,'sign','--v1-signing-enabled','true','--v4-signing-enabled','false',
        '--ks',$Keystore,'--out',$apk) + $signing + @($aligned))
    Invoke-Tool $java @('-jar',$signer,'verify','--min-sdk-version','16','--verbose',$apk)
    Invoke-Tool (Join-Path $tools 'zipalign.exe') @('-c','4',$apk)
} finally {
    $temp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
    $buildPath = [IO.Path]::GetFullPath($work)
    if ($buildPath.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $buildPath)) {
        Remove-Item -LiteralPath $buildPath -Recurse -Force
    }
}
