package com.pixivic.pixidash.legacy;

import com.pixivic.pixidash.legacy.Sprites.Frame;
import com.pixivic.pixidash.legacy.Sprites.Pose;
import com.pixivic.pixidash.legacy.Terrain.Bee;
import com.pixivic.pixidash.legacy.Terrain.Boar;
import com.pixivic.pixidash.legacy.Terrain.Pad;
import com.pixivic.pixidash.legacy.Terrain.Platform;
import static com.pixivic.pixidash.legacy.Terrain.HEIGHT;
import static com.pixivic.pixidash.legacy.Terrain.TILE;
import static com.pixivic.pixidash.legacy.Terrain.clamp;

final class Runner {
    enum Mode { TITLE, ENTERING, RUNNING, DEAD }
    enum Cause { NONE, FALL, WALL, SPIKES, BEE, BOAR }

    interface Sounds {
        void jump();
        void dead();
    }

    static final double STEP = 1.0 / 120;
    static final double GRAVITY = 1000;
    static final double JUMP_SPEED = Math.sqrt(2 * GRAVITY * 3 * TILE);
    static final double PAD_SPEED = Math.sqrt(2 * GRAVITY * 5 * TILE);
    static final int PLAYER_RIGHT = 17;
    private static final double START_SPEED = 156;
    private static final int PLAYER_LEFT = 8;
    private static final int PLAYER_HEIGHT = 36;
    private static final int SPRITE_X = 35;
    private static final int SPRITE_Y = 49;
    private static final double TAP_SPEED = 195;
    private static final double COYOTE_TIME = 0.05;
    private static final double BUFFER_TIME = 0.12;
    private static final int CORNER_CORRECTION = 3;
    private static final double BEE_SPEED = 42;
    private static final int BEE_ALTITUDE = 60;
    private static final double BOAR_SPEED = 30;
    private static final double FRAME_TIME = 0.05;
    private static final double BEE_FRAME_TIME = FRAME_TIME / 2;
    private static final double BEE_TRANSITION_TIME = 0.05;
    private static final double BOAR_FRAME_TIME = 0.1;
    private static final int JUMP_FRAMES = 3;
    private static final double DEATH_GRAVITY = 420;
    private static final double MAX_DEATH_FALL = 180;
    private static final double IMPACT_FALL_SPEED = 75;
    private static final double GROUND_SLIDE_TIME = 0.72;
    private static final double AIR_SLIDE_DRAG = 0.75;

    static final class Player {
        double x = -30;
        double feet = Terrain.LOWEST;
        double velocity, run;
        double jump = -1;
        double landing = -1;
        double stepOffY = Double.NEGATIVE_INFINITY;
        boolean bounced;
        Platform support;
    }

    private final Terrain.RandomSource random;
    private final Sounds sounds;
    private final Frame[] runner, death, bees, transitions, engaged, boars, spikes, grass;
    private final Pose previous = new Pose();
    private final Pose current = new Pose();
    private final Pose obstacleBefore = new Pose();
    private final Pose obstacleAfter = new Pose();
    private final Sprites.Sweep sweep = new Sprites.Sweep();
    private double coyote, buffer, courseTime, distance, deathSpeed, deathDrag;
    private boolean held;
    private int entryTarget;
    int width;
    double time, deathTime, camera;
    Mode mode;
    Cause cause;
    Terrain terrain;
    Player player;

    Runner(int width, Terrain.RandomSource random, Sounds sounds, Sprites sprites) {
        this.width = width;
        this.random = random;
        this.sounds = sounds;
        runner = sprites.frames("runner");
        death = sprites.frames("death");
        bees = sprites.frames("bee");
        transitions = sprites.frames("beeTransition");
        engaged = sprites.frames("engaged");
        boars = sprites.frames("boar");
        spikes = sprites.frames("spikes");
        grass = sprites.frames("grass");
        reset();
    }

    void reset() {
        mode = Mode.TITLE;
        cause = Cause.NONE;
        time = courseTime = deathTime = deathSpeed = deathDrag = camera = distance = buffer = coyote = 0;
        held = false;
        entryTarget = cameraAnchor();
        terrain = new Terrain(random, width);
        player = new Player();
        player.support = terrain.platforms.get(0);
    }

    void start() {
        if (mode == Mode.TITLE) mode = Mode.ENTERING;
    }

    void pressJump() {
        if (mode == Mode.RUNNING || mode == Mode.ENTERING) {
            held = true;
            buffer = BUFFER_TIME;
        }
    }

    void releaseJump() {
        held = false;
        cutJump();
    }

    private void cutJump() {
        if (!player.bounced && player.velocity < -TAP_SPEED) player.velocity = -TAP_SPEED;
    }

    int score() {
        return (int) Math.floor(distance / 8);
    }

    void resize(int width) {
        this.width = width;
        if (mode == Mode.TITLE) entryTarget = cameraAnchor();
        if (mode == Mode.RUNNING) followPlayer();
    }

    private int cameraAnchor() {
        return (int) Math.round(clamp(width * 0.235, 56, 176));
    }

    private void followPlayer() {
        camera = Math.max(0, player.x - cameraAnchor());
    }

    void update(double dt) {
        if (mode == Mode.TITLE) return;
        if (mode == Mode.DEAD) {
            updateDeath(dt);
            return;
        }

        double previousTime = time;
        time += dt;
        if (mode == Mode.ENTERING) {
            player.run += dt;
            player.x = Math.min(entryTarget, player.x + START_SPEED * dt);
            if (player.x == entryTarget) {
                courseTime = Terrain.timeAt(player.x);
                mode = Mode.RUNNING;
            }
            return;
        }

        playerPose(previous);
        double speed = Terrain.speedAt(player.x);
        player.run += dt * (1 + (speed - START_SPEED) * 0.004);
        courseTime += dt;
        terrain.extend(camera + width + 640);
        if (player.support != null) coyote = COYOTE_TIME;
        tryJump();
        movePlayer(speed * dt, dt);
        if (mode == Mode.DEAD) return;

        distance += speed * dt;
        followPlayer();
        coyote = Math.max(0, coyote - dt);
        buffer = Math.max(0, buffer - dt);
        if (player.jump >= 0) player.jump += dt;
        if (player.landing >= 0) {
            player.landing += dt;
            if (player.landing >= (runner.length - JUMP_FRAMES) * FRAME_TIME) {
                player.landing = -1;
                player.run = 0;
            }
        }
        tryPad();
        tryJump();
        playerPose(current);
        if (!checkWalls()) checkObjects(previousTime, dt);
        terrain.trim(camera - 240);
    }

    private static double deathFallDistance(double velocity, double dt) {
        double accelerating = Math.min(dt, (MAX_DEATH_FALL - velocity) / DEATH_GRAVITY);
        return velocity * dt + DEATH_GRAVITY * accelerating * (dt - accelerating / 2);
    }

    private void updateDeath(double dt) {
        deathTime += dt;
        for (int i = 0; i < terrain.platforms.size(); i++) {
            Platform platform = terrain.platforms.get(i);
            if (platform.bee != null) moveBee(platform.bee);
            if (platform.boar != null) moveBoar(platform.boar, dt);
        }
        if (player.feet > HEIGHT + SPRITE_Y) return;

        double deceleration = deathDrag * (player.support != null ? 1 : AIR_SLIDE_DRAG);
        double slideTime = Math.min(dt, deathSpeed / deceleration);
        double dx = deathSpeed * slideTime - deceleration * slideTime * slideTime / 2;
        deathSpeed = Math.max(0, deathSpeed - deceleration * dt);

        double front = player.x + PLAYER_RIGHT;
        for (int i = 0; i < terrain.platforms.size(); i++) {
            Platform platform = terrain.platforms.get(i);
            if (platform.x >= front + dx) break;
            if (platform.x < front) continue;
            double distance = platform.x - front;
            double timeToWall = slideTime * distance / dx;
            double feetAtWall = player.support != null ? player.feet
                : player.feet + deathFallDistance(player.velocity, timeToWall);
            if (feetAtWall <= platform.y || feetAtWall - PLAYER_HEIGHT >= HEIGHT) continue;
            dx = distance;
            deathSpeed = 0;
            break;
        }
        movePlayer(dx, dt);
    }

    private void tryJump() {
        if (buffer > 0 && coyote > 0 && !player.bounced) {
            launch(JUMP_SPEED, false);
            if (!held) cutJump();
        }
    }

    private void launch(double speed, boolean bounced) {
        player.velocity = -speed;
        player.support = null;
        player.stepOffY = Double.NEGATIVE_INFINITY;
        player.jump = 0;
        player.landing = -1;
        player.bounced = bounced;
        coyote = buffer = 0;
        sounds.jump();
    }

    private void movePlayer(double dx, double dt) {
        double fromX = player.x;
        double fromY = player.feet;
        double nextX = fromX + dx;
        boolean wasGrounded = player.support != null;
        if (wasGrounded && nextX - PLAYER_LEFT < player.support.end) {
            player.x = nextX;
            return;
        }
        player.support = null;
        if (wasGrounded) player.stepOffY = fromY;

        boolean dead = mode == Mode.DEAD;
        double nextY = fromY + (dead ? deathFallDistance(player.velocity, dt)
            : player.velocity * dt + GRAVITY * dt * dt / 2);
        player.velocity = dead ? Math.min(MAX_DEATH_FALL, player.velocity + DEATH_GRAVITY * dt)
            : player.velocity + GRAVITY * dt;
        for (int i = 0; i < terrain.platforms.size(); i++) {
            Platform platform = terrain.platforms.get(i);
            if (nextX + PLAYER_RIGHT <= platform.x) break;
            if (fromX - PLAYER_LEFT >= platform.end || platform.y <= player.stepOffY) continue;

            int top = platform.y;
            if (fromX + PLAYER_RIGHT <= platform.x) {
                double vertical = fromY + (nextY - fromY) * ((platform.x - fromX - PLAYER_RIGHT) / dx);
                double overlap = vertical - top;
                if (overlap > 0 && overlap <= CORNER_CORRECTION) {
                    if (player.velocity >= 0) {
                        land(platform, nextX, wasGrounded);
                        return;
                    }
                    nextY -= overlap;
                }
            }
            if (fromY <= top && nextY >= top && nextY > fromY) {
                double landingX = fromX + dx * ((top - fromY) / (nextY - fromY));
                if (landingX + PLAYER_RIGHT >= platform.x && nextX - PLAYER_LEFT < platform.end) {
                    land(platform, nextX, wasGrounded);
                    return;
                }
            }
        }
        player.x = nextX;
        player.feet = nextY;
        if (player.jump < 0) {
            player.jump = (JUMP_FRAMES - 1) * FRAME_TIME;
            player.landing = -1;
        }
        if (!dead && player.feet > HEIGHT + PLAYER_HEIGHT + 8) die(Cause.FALL);
    }

    private void land(Platform platform, double x, boolean wasGrounded) {
        player.x = x;
        player.feet = platform.y;
        player.velocity = 0;
        player.support = platform;
        player.stepOffY = Double.NEGATIVE_INFINITY;
        player.bounced = false;
        if (!wasGrounded) player.landing = 0;
        player.jump = -1;
        coyote = COYOTE_TIME;
    }

    private void tryPad() {
        Pad pad = player.support == null ? null : player.support.pad;
        if (pad != null && pad.used < 0 && player.x >= pad.x + 2 && player.x <= pad.x + 14) {
            pad.used = time;
            launch(PAD_SPEED, true);
        }
    }

    private double beeY(Platform platform, double time) {
        Bee bee = platform.bee;
        double y = platform.y - BEE_ALTITUDE;
        for (int i = 0; i < terrain.platforms.size(); i++) {
            Platform ground = terrain.platforms.get(i);
            double distance = Math.max(0, Math.max(ground.x - bee.x - 19, bee.x - 19 - ground.end));
            y = Math.min(y, ground.y - BEE_ALTITUDE + distance * 2);
        }
        return y + Math.sin(time * 6 + bee.phase) * 2;
    }

    Pose playerPose(Pose out) {
        Frame frame = mode == Mode.DEAD ? death[0] : runner[playerFrame()];
        return out.set(frame, player.x - SPRITE_X, player.feet - SPRITE_Y, false);
    }

    Pose beePose(Platform platform, double time, Pose out) {
        Bee bee = platform.bee;
        Frame frame = bees[loopFrame(time, BEE_FRAME_TIME, bees.length)];
        if (bee.engageStart >= 0 && time >= bee.engageStart) {
            double elapsed = time - bee.engageStart;
            int transition = (int) Math.floor(elapsed / BEE_TRANSITION_TIME);
            double engagedTime = Math.max(0, elapsed - transitions.length * BEE_TRANSITION_TIME);
            frame = transition < transitions.length ? transitions[transition]
                : engaged[loopFrame(engagedTime, BEE_FRAME_TIME, engaged.length)];
        }
        return out.set(frame, bee.x - 19, beeY(platform, time) - 23, false);
    }

    Pose boarPose(Platform platform, double time, Pose out) {
        Boar boar = platform.boar;
        Frame frame = boars[loopFrame(time, BOAR_FRAME_TIME, boars.length)];
        boolean flipped = boar.direction > 0;
        return out.set(frame, boar.x - (flipped ? 15 : 14), platform.y - 17, flipped);
    }

    Pose spikePose(Platform platform, Pose out) {
        return out.set(spikes[platform.spikeHeight == 32 ? 0 : 1], platform.spikeX, platform.y - 31, false);
    }

    private boolean checkWalls() {
        int left = Math.min(previous.left, current.left);
        int right = Math.max(previous.x, current.x) + current.frame.width;
        int top = (int) Math.floor(Math.min(previous.y, current.y) / (double) TILE) * TILE;
        int bottom = Math.min(HEIGHT, Math.max(previous.y, current.y) + current.frame.height);
        int feet = Math.max(previous.y, current.y) + SPRITE_Y;
        for (int i = 0; i < terrain.platforms.size(); i++) {
            Platform platform = terrain.platforms.get(i);
            if (platform.x >= right) break;
            int correction = platform.y <= player.stepOffY ? 0 : CORNER_CORRECTION;
            if (platform.x < left || platform == player.support || feet <= platform.y + correction) continue;
            for (int x = platform.x; x < Math.min(right, platform.end); x += TILE) {
                for (int y = Math.max(top, platform.y); y < bottom; y += TILE) {
                    Pose tile = obstacleBefore.set(grass[Terrain.tileFrame(platform, x, y)], x, y, false);
                    if (hit(Cause.WALL, tile, tile, platform.x)) return true;
                }
            }
        }
        return false;
    }

    private void moveBee(Bee bee) {
        bee.x = bee.crossing + BEE_SPEED * (bee.crossingTime - (courseTime + deathTime));
        if (bee.engageStart < 0 && bee.x - camera <= width / 2.0 + 4 * TILE) bee.engageStart = time + deathTime;
    }

    private static void moveBoar(Boar boar, double dt) {
        boar.x += BOAR_SPEED * boar.direction * dt;
        if (Math.abs(boar.x - boar.home) >= TILE) {
            boar.x = boar.home + TILE * boar.direction;
            boar.direction *= -1;
        }
    }

    private void checkObjects(double previousTime, double dt) {
        for (int i = 0; i < terrain.platforms.size(); i++) {
            Platform platform = terrain.platforms.get(i);
            if (platform.bee != null) {
                boolean placed = !Double.isInfinite(platform.bee.x);
                if (placed) beePose(platform, previousTime, obstacleBefore);
                moveBee(platform.bee);
                beePose(platform, time, obstacleAfter);
                if (hit(Cause.BEE, placed ? obstacleBefore : obstacleAfter, obstacleAfter, Double.POSITIVE_INFINITY)) return;
            }
            if (platform.boar != null) {
                boarPose(platform, previousTime, obstacleBefore);
                moveBoar(platform.boar, dt);
                boarPose(platform, time, obstacleAfter);
                if (hit(Cause.BOAR, obstacleBefore, obstacleAfter, Double.POSITIVE_INFINITY)) return;
            }
            if (platform.spikeHeight > 0) {
                Pose spike = spikePose(platform, obstacleBefore);
                if (hit(Cause.SPIKES, spike, spike, Double.POSITIVE_INFINITY)) return;
            }
        }
    }

    private boolean hit(Cause cause, Pose from, Pose to, double wallX) {
        Pose impact = sweep.contact(previous, current, from, to);
        if (impact == null) return false;
        player.x = Math.min(impact.x + SPRITE_X, wallX - PLAYER_RIGHT);
        player.feet = impact.y + SPRITE_Y;
        if (player.support != null && (player.feet != player.support.y || player.x + PLAYER_RIGHT <= player.support.x
            || player.x - PLAYER_LEFT >= player.support.end)) player.support = null;
        die(cause);
        return true;
    }

    private void die(Cause cause) {
        mode = Mode.DEAD;
        deathTime = 0;
        double speed = Terrain.speedAt(player.x);
        deathSpeed = cause == Cause.WALL || cause == Cause.FALL ? 0 : speed;
        deathDrag = speed / GROUND_SLIDE_TIME;
        player.velocity = clamp(player.velocity, 0, IMPACT_FALL_SPEED);
        this.cause = cause;
        sounds.dead();
    }

    int playerFrame() {
        if (player.jump >= 0) return Math.min(JUMP_FRAMES - 1, (int) Math.floor(player.jump / FRAME_TIME));
        if (player.landing >= 0) return Math.min(runner.length - 1, JUMP_FRAMES + (int) Math.floor(player.landing / FRAME_TIME));
        return loopFrame(player.run, FRAME_TIME, runner.length);
    }

    int padFrame(Pad pad) {
        return pad.used >= 0 ? Math.min(8, (int) Math.floor((time - pad.used) / FRAME_TIME)) : loopFrame(time, 0.1, 6);
    }

    private static int loopFrame(double time, double seconds, int count) {
        return (int) (Math.floor(time / seconds) % count);
    }
}