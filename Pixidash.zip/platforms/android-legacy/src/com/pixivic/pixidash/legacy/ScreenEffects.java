package com.pixivic.pixidash.legacy;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;

final class ScreenEffects {
    static final double WIPE_TIME = 0.2;
    static final int DITHER_LEVELS = 16;
    private static final double SHAKE_TIME = 0.32;
    private static final double FLASH_RISE = 0.045;
    private static final double FLASH_TIME = 0.23;
    private static final int[] BAYER = {
         0, 48, 12, 60,  3, 51, 15, 63,
        32, 16, 44, 28, 35, 19, 47, 31,
         8, 56,  4, 52, 11, 59,  7, 55,
        40, 24, 36, 20, 43, 27, 39, 23,
         2, 50, 14, 62,  1, 49, 13, 61,
        34, 18, 46, 30, 33, 17, 45, 29,
        10, 58,  6, 54,  9, 57,  5, 53,
        42, 26, 38, 22, 41, 25, 37, 21
    };

    private final BitmapShader[] masks = new BitmapShader[DITHER_LEVELS];
    private final BitmapShader[] flashes = new BitmapShader[DITHER_LEVELS];
    private final Paint effect = new Paint();
    private final Paint mask = new Paint();
    private final Path wipe = new Path();
    private Bitmap overlay;
    private Canvas overlayCanvas;

    ScreenEffects() {
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
    }

    static int ditherLevel(double visibility) {
        return (int) Math.round(Terrain.clamp(visibility, 0, 1) * DITHER_LEVELS);
    }

    private static BitmapShader tile(BitmapShader[] cache, int level, int color) {
        BitmapShader shader = cache[level];
        if (shader == null) {
            int[] pixels = new int[BAYER.length];
            int threshold = level * BAYER.length / DITHER_LEVELS;
            for (int i = 0; i < pixels.length; i++) {
                if (BAYER[i] < threshold) pixels[i] = color;
            }
            Bitmap bitmap = Bitmap.createBitmap(pixels, 8, 8, Bitmap.Config.ARGB_8888);
            bitmap.setDensity(Bitmap.DENSITY_NONE);
            shader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            cache[level] = shader;
        }
        return shader;
    }

    Canvas beginOverlay(int width, int height) {
        if (overlay == null || overlay.getWidth() != width || overlay.getHeight() != height) {
            overlay = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            overlay.setDensity(Bitmap.DENSITY_NONE);
            overlayCanvas = new Canvas(overlay);
        } else {
            overlayCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        }
        return overlayCanvas;
    }

    void drawOverlay(Canvas canvas, int level, Paint pixels) {
        mask.setShader(tile(masks, level, Color.WHITE));
        overlayCanvas.drawRect(0, 0, overlay.getWidth(), overlay.getHeight(), mask);
        canvas.drawBitmap(overlay, 0, 0, pixels);
    }

    void shakeWorld(Canvas canvas, double time) {
        if (time >= SHAKE_TIME) return;
        double strength = 1 - time / SHAKE_TIME;
        canvas.drawColor(0xff063c3c);
        canvas.translate(Math.round(Math.sin(time * 151 + 0.8) * strength * 9),
            Math.round(Math.cos(time * 127) * strength * 6));
    }

    void drawImpact(Canvas canvas, int width, int height, double time) {
        if (time >= FLASH_TIME) return;
        double intensity = time < FLASH_RISE ? time / FLASH_RISE : (FLASH_TIME - time) / (FLASH_TIME - FLASH_RISE);
        int level = ditherLevel(intensity);
        if (level == 0) return;
        effect.setColor(0x6cff1c2b);
        if (level < DITHER_LEVELS) {
            effect.setAlpha(255);
            effect.setShader(tile(flashes, level, 0x6cff1c2b));
        }
        canvas.drawRect(0, 0, width, height, effect);
        effect.setShader(null);
    }

    void drawReturnWipe(Canvas canvas, int width, int height, double time) {
        boolean covering = time <= WIPE_TIME;
        double progress = time / WIPE_TIME - (covering ? 0 : 1);
        int slant = (int) Math.round(Math.min(width * 0.25, height * 0.68));
        int front = (int) Math.floor(progress * (width + slant));
        int outer = covering ? 0 : width;
        int edge = wipeEdge(front, slant, width, 0, height);
        wipe.rewind();
        wipe.moveTo(outer, 0);
        wipe.lineTo(edge, 0);
        for (int y = 1; y < height; y++) {
            int next = wipeEdge(front, slant, width, y, height);
            if (next == edge) continue;
            wipe.lineTo(edge, y);
            wipe.lineTo(next, y);
            edge = next;
        }
        wipe.lineTo(edge, height);
        wipe.lineTo(outer, height);
        wipe.close();
        effect.setColor(Color.BLACK);
        canvas.drawPath(wipe, effect);
    }

    private static int wipeEdge(int front, int slant, int width, int row, int height) {
        return Math.max(0, Math.min(width, front - Math.round(slant * (height - row - 1f) / height)));
    }
}
