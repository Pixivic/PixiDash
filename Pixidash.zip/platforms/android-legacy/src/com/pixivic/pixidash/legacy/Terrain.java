package com.pixivic.pixidash.legacy;

import java.util.ArrayList;

final class Terrain {
    static final int TILE = 16;
    static final int HEIGHT = 352;
    static final int LOWEST = HEIGHT - 4 * TILE;
    static final int HIGHEST = 11 * TILE;
    private static final double START_SPEED = 156;
    private static final double MAX_SPEED = 308;
    private static final double ACCELERATION = 1.05;

    static final class Platform {
        final int x, end, y;
        final ArrayList<Bush> bushes = new ArrayList<Bush>();
        int landingRoom, spikeX, spikeHeight;
        Pad pad;
        Bee bee;
        Boar boar;

        Platform(int x, int end, int y) {
            this.x = x;
            this.end = end;
            this.y = y;
        }
    }

    static final class Pad {
        final int x;
        double used = -1;

        Pad(int x) {
            this.x = x;
        }
    }

    static final class Bush {
        final int x, variant, flower;
        final boolean big;

        Bush(int x, boolean big, int variant, int flower) {
            this.x = x;
            this.big = big;
            this.variant = variant;
            this.flower = flower;
        }
    }

    static final class Bee {
        final int crossing;
        final double crossingTime, phase;
        double x = Double.POSITIVE_INFINITY;
        double engageStart = -1;

        Bee(int crossing, double phase) {
            this.crossing = crossing;
            this.crossingTime = timeAt(crossing);
            this.phase = phase;
        }
    }

    static final class Boar {
        final int home;
        double x;
        int direction = -1;

        Boar(int center) {
            home = center;
            x = center;
        }
    }

    interface RandomSource {
        double next();
    }

    private enum Style {
        STONE(4, 6, 0.14, 0.23),
        SHELF(7, 10, 0.17, 0.28),
        LEDGE(9, 14, 0.27, 0.39),
        CLEARING(16, 22, 0.19, 0.31);

        final int minTiles, maxTiles;
        final double minSpacing, maxSpacing;

        Style(int minTiles, int maxTiles, double minSpacing, double maxSpacing) {
            this.minTiles = minTiles;
            this.maxTiles = maxTiles;
            this.minSpacing = minSpacing;
            this.maxSpacing = maxSpacing;
        }
    }

    private static final class Step {
        final int rise;
        final Style style;

        Step(int rise, Style style) {
            this.rise = rise;
            this.style = style;
        }
    }

    private static final Step[][] SECTIONS = {
        {new Step(1, Style.SHELF), new Step(1, Style.STONE), new Step(1, Style.CLEARING)},
        {new Step(-2, Style.LEDGE), new Step(0, Style.STONE), new Step(1, Style.SHELF), new Step(1, Style.CLEARING)},
        {new Step(2, Style.SHELF), new Step(0, Style.STONE), new Step(-1, Style.LEDGE), new Step(1, Style.CLEARING)},
        {new Step(0, Style.LEDGE), new Step(1, Style.STONE), new Step(0, Style.STONE), new Step(-1, Style.CLEARING)},
        {new Step(1, Style.LEDGE), new Step(1, Style.SHELF), new Step(0, Style.CLEARING), new Step(-2, Style.SHELF)}
    };

    final ArrayList<Platform> platforms = new ArrayList<Platform>();
    private final RandomSource random;
    private boolean descending;
    private int section = -1;
    private int sectionStep;
    private int direction = 1;
    private double lastPad = Double.NEGATIVE_INFINITY;
    private int spikeWait = 2;

    Terrain(RandomSource random, int width) {
        this.random = random;
        Platform first = new Platform(-12 * TILE, tileUp(Math.max(704, width * 0.86)), LOWEST);
        addBushes(first, 0, 0, true);
        platforms.add(first);
        extend(width + 512);
    }

    static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    static int tileUp(double value) {
        return (int) Math.ceil(value / TILE) * TILE;
    }

    static double speedAt(double x) {
        return Math.min(MAX_SPEED, Math.sqrt(START_SPEED * START_SPEED + 2 * ACCELERATION * Math.max(0, x)));
    }

    static double timeAt(double x) {
        double speed = speedAt(x);
        double rampTime = (speed - START_SPEED) / ACCELERATION;
        double rampDistance = (speed + START_SPEED) * rampTime / 2;
        return rampTime + Math.max(0, x - rampDistance) / MAX_SPEED;
    }

    static int tileFrame(Platform platform, int x, int y) {
        int column = x == platform.x ? 0 : x == platform.end - TILE ? 2 : 1;
        int row = y == platform.y ? 0 : y == HEIGHT - TILE ? 2 : 1;
        return row * 3 + column;
    }

    private static int approach(double speed) {
        return tileUp(speed * 0.37);
    }

    private static int recovery(double speed) {
        return tileUp(speed * 0.55 + 1.5 * TILE);
    }

    private static double lengthBonus(Platform platform) {
        return clamp((platform.end - platform.x - 4 * TILE) / (32.0 * TILE), 0, 1);
    }

    void extend(double limit) {
        Platform previous = platforms.get(platforms.size() - 1);
        while (previous.end < limit) {
            Platform next = nextPlatform(previous);
            if (platforms.size() > 1 || previous.x >= 0) decorate(previous);
            platforms.add(next);
            previous = next;
        }
    }

    private Platform nextPlatform(Platform previous) {
        int end = previous.end;
        int y = previous.y;
        if (y == HIGHEST) descending = true;
        if (y == LOWEST) descending = false;

        boolean sectionEnded = section < 0 || sectionStep == SECTIONS[section].length;
        boolean pad = sectionEnded && y >= LOWEST - 2 * TILE && previous.x >= 0
            && end - previous.x - previous.landingRoom >= 4 * TILE && end - lastPad > 1100
            && random.next() < 0.42;
        if (!pad && sectionEnded) startSection(y);

        Step step = pad ? null : SECTIONS[section][sectionStep++];
        Style style = pad ? Style.LEDGE : step.style;
        int change = pad ? 4 : step.rise * direction;
        if ((y == LOWEST && change < 0) || (y == HIGHEST && change > 0)) change = -change;
        int top = (int) clamp(y - change * TILE, HIGHEST, LOWEST);
        boolean shortPlatform = style == Style.STONE || style == Style.SHELF;
        double lift = pad ? Runner.PAD_SPEED : Runner.JUMP_SPEED;
        double speedAtHeight = Math.sqrt(lift * lift - 2 * Runner.GRAVITY * (y - top));
        double earliest = Math.max(0, (lift - speedAtHeight) / Runner.GRAVITY);
        double latest = (lift + speedAtHeight) / Runner.GRAVITY;
        int gap = pickGap(end, earliest, latest, style, shortPlatform, pad);
        int landingRoom = tileUp(Math.max(TILE, speedAt(end + 160) * latest - gap - (pad ? 26 : 0)));
        double speed = speedAt(end + 480);
        int runway = landingRoom + (shortPlatform ? 3 * TILE
            : approach(speed) + recovery(speed) + (style == Style.CLEARING ? 6 : 3) * TILE);
        int tiles = style.minTiles + (int) (random.next() * (style.maxTiles - style.minTiles + 1));
        if (pad) {
            previous.pad = new Pad(end - 2 * TILE);
            lastPad = end;
        }
        Platform next = new Platform(end + gap, end + gap + Math.max(runway, tiles * TILE), top);
        next.landingRoom = landingRoom;
        return next;
    }

    private void startSection(int y) {
        int next = (int) (random.next() * (SECTIONS.length - (section < 0 ? 0 : 1)));
        if (section >= 0 && next >= section) next++;
        section = next;
        sectionStep = 0;
        int firstStep = SECTIONS[section][0].rise;
        if (firstStep < 0 && y >= LOWEST - TILE) direction = -1;
        else if (firstStep < 0 && y <= HIGHEST + TILE) direction = 1;
        else direction = descending ? -1 : 1;
    }

    private int pickGap(int edge, double earliest, double latest, Style style, boolean shortPlatform, boolean pad) {
        int minOffset = pad ? -30 : -24;
        int maxOffset = pad ? -26 : -16;
        int minGap = Math.max(shortPlatform ? TILE : 2 * TILE,
            tileUp(maxOffset + Runner.PLAYER_RIGHT + 4 + speedAt(edge + 160) * earliest));
        double maxGap = Math.min(144, Math.floor((minOffset - 12 + speedAt(edge - 32) * latest) / TILE) * TILE);
        double preferred = pad ? speedAt(edge) * (0.31 + random.next() * 0.06) - 17
            : speedAt(edge) * (style.minSpacing + random.next() * (style.maxSpacing - style.minSpacing)) - 4;
        return (int) clamp(tileUp(preferred), minGap, maxGap);
    }

    private void decorate(Platform platform) {
        double speed = speedAt(platform.end);
        int first = platform.x + platform.landingRoom + approach(speed);
        int last = platform.end - recovery(speed);
        int reservedStart = 0;
        int reservedEnd = 0;
        if (platform.pad != null) {
            reservedStart = platform.pad.x - TILE;
            reservedEnd = platform.pad.x + 2 * TILE;
        } else if (last >= first) {
            int room = (last - first) / TILE;
            double choose = random.next();
            double bonus = lengthBonus(platform);
            double spikeChance = 0.28 + 0.28 * bonus;
            double boarChance = 0.15 + 0.16 * bonus;
            boolean spike = spikeWait >= 2 || choose < spikeChance;
            boolean patrol = !spike && choose < spikeChance + boarChance && room >= 2;
            int inset = patrol ? 1 : 0;
            int slot = inset + (int) ((room + 1 - 2 * inset) * random.next());
            int center = first + slot * TILE + TILE / 2;
            if (spike) {
                platform.spikeX = center - TILE / 2;
                platform.spikeHeight = random.next() < 0.23 ? 32 : 16;
                spikeWait = 0;
                reservedStart = center - TILE;
                reservedEnd = center + TILE;
            } else if (patrol) {
                platform.boar = new Boar(center);
                reservedStart = center - 2 * TILE;
                reservedEnd = center + 2 * TILE;
            } else if (choose < 0.94) {
                platform.bee = new Bee(center, random.next() * Math.PI * 2);
            }
            if (!spike) spikeWait++;
        }
        addBushes(platform, reservedStart, reservedEnd, false);
    }

    private void addBushes(Platform platform, int reservedStart, int reservedEnd, boolean starting) {
        double patch = random.next();
        double bonus = lengthBonus(platform);
        boolean spike = platform.spikeHeight > 0;
        double bareChance = (spike ? 0.03 : 0.015) * (1 - 0.8 * bonus);
        if (!starting && patch < bareChance) return;
        boolean clustered = starting || patch >= 0.52;
        double density = starting ? 0.48 : (clustered ? 0.34 : 0.23) + 0.09 * bonus + (spike ? 0 : 0.05);
        Flowers flowers = new Flowers(patch > 0.79 ? 0.5 : 0.34);
        int firstOpen = Integer.MIN_VALUE;
        boolean afterBig = false;
        boolean nextToBush = false;
        for (int x = platform.x + TILE; x < platform.end - TILE; x += TILE) {
            boolean fits = fitsBush(platform.end, x, TILE, reservedStart, reservedEnd);
            if (fits && firstOpen == Integer.MIN_VALUE) firstOpen = x;
            double chance = density + (nextToBush && clustered ? 0.26 : 0);
            if (!fits || random.next() > chance) {
                afterBig = false;
                nextToBush = false;
                continue;
            }
            boolean big = fitsBush(platform.end, x, 2 * TILE, reservedStart, reservedEnd)
                && random.next() < (afterBig ? 0.18 : 0.45);
            platform.bushes.add(new Bush(x, big, random.next() < 0.5 ? 1 : 0, flowers.pick()));
            if (big) x += TILE;
            afterBig = big;
            nextToBush = true;
        }
        if (platform.bushes.isEmpty() && firstOpen != Integer.MIN_VALUE) {
            platform.bushes.add(new Bush(firstOpen, false, random.next() < 0.5 ? 1 : 0, flowers.pick()));
        }
    }

    private static boolean fitsBush(int end, int x, int width, int start, int stop) {
        return x + width <= end - TILE && (start == stop || x + width <= start || x >= stop);
    }

    private final class Flowers {
        final double chance;
        int colors = 0x1e;
        int last;

        Flowers(double chance) {
            this.chance = chance;
        }

        int pick() {
            if (random.next() >= chance) return 0;
            if (colors == 0) colors = 0x1e;
            int choices = colors & ~(1 << last);
            int choice = (int) (random.next() * Integer.bitCount(choices));
            while (choice-- > 0) choices &= choices - 1;
            last = Integer.numberOfTrailingZeros(choices);
            colors &= ~(1 << last);
            return last;
        }
    }

    void trim(double left) {
        while (platforms.size() > 1 && platforms.get(0).end < left) platforms.remove(0);
    }
}
