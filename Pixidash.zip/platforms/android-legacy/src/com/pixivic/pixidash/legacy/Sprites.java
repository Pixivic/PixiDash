package com.pixivic.pixidash.legacy;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

final class Sprites {
    static final class Frame {
        final String sheet;
        final int width, height, sx, sy, left, top, maskWidth, maskHeight;
        final byte[] mask;

        Frame(String sheet, DataInputStream data) throws IOException {
            this.sheet = sheet;
            width = data.readInt();
            height = data.readInt();
            sx = data.readInt();
            sy = data.readInt();
            left = data.readInt();
            top = data.readInt();
            maskWidth = data.readInt();
            maskHeight = data.readInt();
            mask = new byte[data.readInt()];
            data.readFully(mask);
        }
    }

    static final class Pose {
        Frame frame;
        int x, y, left, right, top, bottom;
        boolean flipped;

        Pose set(Frame frame, double px, double py, boolean flipped) {
            this.frame = frame;
            x = (int) Math.round(px);
            y = (int) Math.round(py);
            this.flipped = flipped;
            left = x + (flipped ? frame.width - frame.left - frame.maskWidth : frame.left);
            top = y + frame.top;
            right = left + frame.maskWidth;
            bottom = top + frame.maskHeight;
            return this;
        }

        private boolean opaque(int px, int py) {
            int column = flipped ? right - px - 1 : px - left;
            int index = (py - top) * frame.maskWidth + column;
            return (frame.mask[index >>> 3] & (1 << (index & 7))) != 0;
        }

        boolean overlaps(Pose other) {
            int start = Math.max(left, other.left);
            int end = Math.min(right, other.right);
            if (start >= end) return false;
            int floor = Math.min(bottom, other.bottom);
            for (int py = Math.max(top, other.top); py < floor; py++) {
                for (int px = start; px < end; px++) {
                    if (opaque(px, py) && other.opaque(px, py)) return true;
                }
            }
            return false;
        }
    }

    static final class Sweep {
        private final Pose first = new Pose();
        private final Pose second = new Pose();
        private double[] crossings = new double[24];

        Pose contact(Pose a, Pose endA, Pose b, Pose endB) {
            if (Math.max(a.x, endA.x) + a.frame.width <= Math.min(b.x, endB.x)
                || Math.max(b.x, endB.x) + b.frame.width <= Math.min(a.x, endA.x)
                || Math.max(a.y, endA.y) + a.frame.height <= Math.min(b.y, endB.y)
                || Math.max(b.y, endB.y) + b.frame.height <= Math.min(a.y, endA.y)) return null;

            int ax = Math.abs(endA.x - a.x);
            int ay = Math.abs(endA.y - a.y);
            int bx = Math.abs(endB.x - b.x);
            int by = Math.abs(endB.y - b.y);
            int size = 2 + ax + ay + bx + by;
            if (size > crossings.length) crossings = new double[size];
            crossings[0] = 0;
            crossings[1] = 1;
            int count = addCrossings(2, ax);
            count = addCrossings(count, ay);
            count = addCrossings(count, bx);
            addCrossings(count, by);
            Arrays.sort(crossings, 0, size);
            for (int i = 1; i < size; i++) {
                if (crossings[i] == crossings[i - 1]) continue;
                double time = (crossings[i] + crossings[i - 1]) / 2;
                Pose sample = interpolate(a, endA, first, time);
                if (sample.overlaps(interpolate(b, endB, second, time))) return sample;
            }
            return endA.overlaps(endB) ? endA : null;
        }

        private int addCrossings(int count, int steps) {
            for (int i = 0; i < steps; i++) crossings[count++] = (i + 0.5) / steps;
            return count;
        }

        private static Pose interpolate(Pose from, Pose to, Pose result, double time) {
            if (from.x == to.x && from.y == to.y) return from;
            return result.set(from.frame, from.x + (to.x - from.x) * time,
                from.y + (to.y - from.y) * time, from.flipped);
        }
    }

    private final Map<String, Frame[]> frames = new HashMap<String, Frame[]>();

    Sprites(InputStream source) throws IOException {
        DataInputStream data = new DataInputStream(source);
        int sheets = data.readInt();
        for (int i = 0; i < sheets; i++) {
            String sheet = data.readUTF();
            Frame[] sequence = new Frame[data.readInt()];
            for (int f = 0; f < sequence.length; f++) sequence[f] = new Frame(sheet, data);
            frames.put(sheet, sequence);
        }
    }

    Frame[] frames(String name) {
        return frames.get(name);
    }
}