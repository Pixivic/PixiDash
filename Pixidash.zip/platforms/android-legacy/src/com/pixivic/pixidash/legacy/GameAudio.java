package com.pixivic.pixidash.legacy;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.util.Log;
import java.io.IOException;

final class GameAudio implements Runner.Sounds {
    static final int NONE = -1, MENU = 0, RUN = 1, RESULT = 2;
    private static final String[] TRACKS = {
        "Kevin MacLeod - Pixelland.mp3", "Jeremy Blake - Powerup!.mp3", "Game Over.mp3"
    };
    private final Context context;
    private final SoundPool effects = new SoundPool(2, AudioManager.STREAM_MUSIC, 0);
    private final int jumpSound, deathSound;
    private int requested = NONE;
    private MediaPlayer music;
    private boolean ready, active;
    boolean musicOn, soundOn;

    GameAudio(Context context, boolean musicOn, boolean soundOn) {
        this.context = context;
        this.musicOn = musicOn;
        this.soundOn = soundOn;
        jumpSound = loadEffect("jump.WAV");
        deathSound = loadEffect("dead.WAV");
    }

    private int loadEffect(String file) {
        try {
            AssetFileDescriptor asset = context.getAssets().openFd("audio/" + file);
            try {
                return effects.load(asset, 1);
            } finally {
                asset.close();
            }
        } catch (IOException failure) {
            Log.w("PixiDash", "Could not load " + file, failure);
            return 0;
        }
    }

    void track(int next) {
        if (requested == next) return;
        requested = next;
        releaseMusic();
        if (next == NONE || !musicOn) return;
        loadMusic(next);
    }

    private void loadMusic(final int track) {
        MediaPlayer player = new MediaPlayer();
        music = player;
        player.setAudioStreamType(AudioManager.STREAM_MUSIC);
        player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer prepared) {
                if (music != prepared) return;
                prepared.setLooping(true);
                prepared.setVolume(0.4f, 0.4f);
                ready = true;
                sync();
            }
        });
        player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer failed, int reason, int extra) {
                if (music == failed) releaseMusic();
                Log.w("PixiDash", "Could not play " + TRACKS[track] + " (" + reason + ", " + extra + ")");
                return true;
            }
        });
        try {
            AssetFileDescriptor asset = context.getAssets().openFd("audio/" + TRACKS[track]);
            try {
                player.setDataSource(asset.getFileDescriptor(), asset.getStartOffset(), asset.getLength());
            } finally {
                asset.close();
            }
            player.prepareAsync();
        } catch (IOException failure) {
            releaseMusic();
            Log.w("PixiDash", "Could not load " + TRACKS[track], failure);
        }
    }

    void setMusic(boolean enabled) {
        musicOn = enabled;
        if (musicOn && music == null && requested != NONE) loadMusic(requested);
        else sync();
    }

    void setActive(boolean enabled) {
        active = enabled;
        if (!enabled) effects.autoPause();
        sync();
    }

    private void sync() {
        if (!ready) return;
        if (active && musicOn) {
            if (!music.isPlaying()) music.start();
        } else if (music.isPlaying()) {
            music.pause();
        }
    }

    @Override public void jump() {
        if (active && soundOn && jumpSound != 0) {
            float pitch = 0.9f + (float) Math.random() * 0.2f;
            effects.play(jumpSound, 0.55f, 0.55f, 1, 0, pitch);
        }
    }

    @Override public void dead() {
        if (active && soundOn && deathSound != 0) effects.play(deathSound, 0.65f, 0.65f, 1, 0, 1);
    }

    private void releaseMusic() {
        ready = false;
        if (music != null) {
            music.release();
            music = null;
        }
    }

    void close() {
        releaseMusic();
        effects.release();
    }
}
