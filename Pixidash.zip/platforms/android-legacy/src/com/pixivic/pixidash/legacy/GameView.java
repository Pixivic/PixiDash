package com.pixivic.pixidash.legacy;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import com.pixivic.pixidash.legacy.Sprites.Pose;
import com.pixivic.pixidash.legacy.Terrain.Bush;
import com.pixivic.pixidash.legacy.Terrain.Platform;
import static com.pixivic.pixidash.legacy.Terrain.HEIGHT;
import static com.pixivic.pixidash.legacy.Terrain.TILE;

final class GameView extends View {
    private enum Overlay { INTRO, TITLE, CREDITS, RESULT }

    private static final int FPS = 30;
    private static final double INTRO_DITHER_TIME = 0.48;
    private static final double TITLE_DITHER_TIME = 0.42;
    private static final double CREDITS_DITHER_TIME = 0.56;
    private static final double RESULT_DITHER_TIME = 0.34;
    private static final double FALL_RESULT_DELAY = 0.28;
    private static final double IMPACT_RESULT_DELAY = 0.84;
    private static final int CREAM = 0xfffff9e1;
    private static final int GOLD = 0xffffdf70;
    private static final String BREATH = "Huss... huss... huss...";
    private static final String[][] ART = {
        {"sky", "Backgrounds/Background-1.png"}, {"mountains", "Backgrounds/Background-2.png"},
        {"clouds", "Backgrounds/Background-3.png"}, {"trees", "Backgrounds/Background-4.png"},
        {"runner", "Pixivic-Run.png"}, {"death", "Pixivic-death.png"}, {"grass", "Grass-Tiles.png"},
        {"bee", "Bee-fly.png"}, {"engaged", "Bee-fly-engage.png"}, {"beeTransition", "Bee-transition.png"},
        {"boar", "boar.png"}, {"spikes", "Spikes.png"}, {"bushes", "bushes.png"},
        {"pad", "Jump-Pad.png"}, {"sprung", "Jump-Pad-activate.png"}, {"signs", "Jump-Pad-Signage.png"},
        {"logo", "titleLogo.png"}
    };

    private final Runner game;
    private final GameAudio audio;
    private final SharedPreferences settings;
    private final Map<String, Bitmap> art = new HashMap<String, Bitmap>();
    private final Bitmap[][] ground = new Bitmap[(Terrain.LOWEST - Terrain.HIGHEST) / TILE + 1][3];
    private final Paint pixels = new Paint();
    private final Paint ink = new Paint();
    private final Paint type = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect source = new Rect();
    private final Rect target = new Rect();
    private final Path corner = new Path();
    private final ScreenEffects effects = new ScreenEffects();
    private final Pose drawing = new Pose();
    private final Typeface font;
    private boolean intro = true;
    private boolean credits;
    private boolean result;
    private boolean active;
    private boolean holding;
    private double introElapsed = -1;
    private double creditsProgress;
    private double returnElapsed = -1;
    private float scale = 1;
    private float left, top;
    private double cloudDrift;
    private double breathStart = -1;
    private double accumulator;
    private long frameTime;
    private long frameAnchor;
    private int frameNumber;

    GameView(Context context) throws IOException {
        super(context);
        setFocusableInTouchMode(true);
        setClickable(true);
        setContentDescription("PixiDash. Tap to start.");
        setBackgroundColor(Color.BLACK);
        pixels.setFilterBitmap(false);
        pixels.setAntiAlias(false);
        type.setTextAlign(Paint.Align.CENTER);
        Typeface face;
        try {
            face = Typeface.createFromAsset(context.getAssets(), "fonts/Pix32.ttf");
        } catch (RuntimeException failure) {
            face = Typeface.MONOSPACE;
        }
        font = face;
        for (String[] sprite : ART) art.put(sprite[0], bitmap(context, "art/" + sprite[1]));
        buildGround();
        InputStream masks = context.getAssets().open("sprite-frames.dat");
        Sprites sprites;
        try {
            sprites = new Sprites(masks);
        } catch (IOException failure) {
            throw new IOException("Could not read sprite-frames.dat", failure);
        } finally {
            masks.close();
        }
        settings = context.getSharedPreferences("pixidash", Context.MODE_PRIVATE);
        audio = new GameAudio(context, settings.getBoolean("music", true), settings.getBoolean("sound", true));
        final Random random = new Random();
        game = new Runner(626, new Terrain.RandomSource() {
            @Override public double next() {
                return random.nextDouble();
            }
        }, audio, sprites);
    }

    private static Bitmap bitmap(Context context, String name) throws IOException {
        InputStream stream;
        try {
            stream = context.getAssets().open(name);
        } catch (IOException failure) {
            throw new IOException("Could not open " + name, failure);
        }
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inScaled = false;
            Bitmap decoded = BitmapFactory.decodeStream(stream, null, options);
            if (decoded == null) throw new IOException("Could not decode " + name);
            decoded.setDensity(Bitmap.DENSITY_NONE);
            return decoded;
        } finally {
            stream.close();
        }
    }

    private void buildGround() {
        Bitmap atlas = art.get("grass");
        for (int row = 0; row < ground.length; row++) {
            int height = HEIGHT - (Terrain.HIGHEST + row * TILE);
            for (int column = 0; column < 3; column++) {
                Bitmap strip = Bitmap.createBitmap(TILE, height, Bitmap.Config.ARGB_8888);
                strip.setDensity(Bitmap.DENSITY_NONE);
                Canvas baked = new Canvas(strip);
                for (int y = 0; y < height; y += TILE) {
                    int sy = y == 0 ? 0 : y == height - TILE ? 2 * TILE : TILE;
                    sprite(baked, atlas, column * TILE, sy, TILE, TILE, 0, y);
                }
                ground[row][column] = strip;
            }
        }
    }

    @Override protected void onSizeChanged(int w, int h, int oldWidth, int oldHeight) {
        super.onSizeChanged(w, h, oldWidth, oldHeight);
        if (w <= 0 || h <= 0) return;
        scale = Math.min(w / 500f, h / (float) HEIGHT);
        int width = Math.min(896, Math.round(w / scale));
        left = (w - width * scale) / 2;
        top = (h - HEIGHT * scale) / 2;
        game.resize(width);
    }

    private boolean animated() {
        if (!active) return false;
        if (intro) return introElapsed >= 0;
        if (returnElapsed >= 0) return true;
        if (credits) return creditsProgress < 1;
        return !result || game.deathTime < resultDelay() + RESULT_DITHER_TIME;
    }

    private final Runnable frame = new Runnable() {
        @Override public void run() {
            if (!animated()) return;
            long now = SystemClock.uptimeMillis();
            double elapsed = Math.min((now - frameTime) / 1000.0, 0.1);
            frameTime = now;
            if (game.mode != Runner.Mode.DEAD) cloudDrift = (cloudDrift + elapsed * 7) % art.get("clouds").getWidth();
            accumulator += elapsed;
            while (accumulator >= Runner.STEP) {
                game.update(Runner.STEP);
                accumulator -= Runner.STEP;
            }
            updateScreen(elapsed);
            invalidate();
            if (animated()) {
                long afterUpdate = SystemClock.uptimeMillis();
                long next = frameAnchor + ++frameNumber * 1000L / FPS;
                if (next <= afterUpdate) {
                    frameAnchor = afterUpdate;
                    frameNumber = 1;
                    next = frameAnchor + 1000 / FPS;
                }
                postDelayed(this, next - afterUpdate);
            }
        }
    };

    private void resetClock() {
        removeCallbacks(frame);
        frameAnchor = frameTime = SystemClock.uptimeMillis();
        frameNumber = 1;
        accumulator = 0;
        if (animated()) postDelayed(frame, 1000 / FPS);
        invalidate();
    }

    private double resultDelay() {
        return game.cause == Runner.Cause.FALL ? FALL_RESULT_DELAY : IMPACT_RESULT_DELAY;
    }

    private void updateScreen(double elapsed) {
        if (intro) {
            introElapsed += elapsed;
            if (introElapsed >= INTRO_DITHER_TIME) intro = false;
        }
        if (game.mode == Runner.Mode.TITLE) {
            double step = elapsed / CREDITS_DITHER_TIME;
            creditsProgress = credits ? Math.min(1, creditsProgress + step) : Math.max(0, creditsProgress - step);
        }
        if (returnElapsed >= 0) {
            returnElapsed += elapsed;
            if (game.mode == Runner.Mode.DEAD && returnElapsed >= ScreenEffects.WIPE_TIME) {
                returnElapsed = ScreenEffects.WIPE_TIME;
                title();
            } else if (returnElapsed >= 2 * ScreenEffects.WIPE_TIME) {
                returnElapsed = -1;
            }
        }
        if (game.mode == Runner.Mode.RUNNING && breathStart < 0) breathStart = game.time + 0.18;
        if (game.mode != Runner.Mode.DEAD || result) return;
        result = game.deathTime >= resultDelay();
        audio.track(result ? GameAudio.RESULT : GameAudio.NONE);
        if (result) setContentDescription("Game over. Score " + game.score() + ". Tap to return to the menu.");
    }

    void setActive(boolean enabled) {
        active = enabled;
        audio.setActive(enabled);
        if (!enabled) release();
        resetClock();
    }

    void close() {
        setActive(false);
        audio.close();
    }

    private void title() {
        game.reset();
        result = false;
        credits = false;
        creditsProgress = 0;
        breathStart = -1;
        audio.track(GameAudio.MENU);
        setContentDescription("PixiDash. Tap to start running.");
    }

    boolean back() {
        if (intro) return introElapsed >= 0;
        if (returnElapsed >= 0) return true;
        if (game.mode == Runner.Mode.TITLE && !credits) return creditsProgress > 0;
        if (credits) {
            credits = false;
            setContentDescription("PixiDash. Tap to start running.");
        } else if (game.mode == Runner.Mode.DEAD) {
            returnElapsed = 0;
        } else {
            title();
        }
        resetClock();
        return true;
    }

    private void press(float x, float y) {
        if (returnElapsed >= 0) return;
        if (intro) {
            if (introElapsed < 0) {
                introElapsed = 0;
                title();
                resetClock();
            }
        } else if (credits) {
            if (creditsProgress > 0.5) back();
        } else if (result) {
            back();
        } else if (game.mode == Runner.Mode.TITLE) {
            if (creditsProgress > 0) return;
            if (x >= 10 && x <= 119 && y >= 10 && y <= 40) {
                audio.setMusic(!audio.musicOn);
                settings.edit().putBoolean("music", audio.musicOn).apply();
            } else if (x >= 10 && x <= 119 && y >= 46 && y <= 76) {
                audio.soundOn = !audio.soundOn;
                settings.edit().putBoolean("sound", audio.soundOn).apply();
            } else if (x >= game.width - 110 && x <= game.width - 10 && y >= 10 && y <= 40) {
                credits = true;
                setContentDescription("Credits. Tap to return.");
            } else {
                game.start();
                audio.track(GameAudio.RUN);
                setContentDescription("Running. Tap to jump. Hold for a higher jump.");
            }
            resetClock();
        } else if (game.mode == Runner.Mode.RUNNING || game.mode == Runner.Mode.ENTERING) {
            holding = true;
            game.pressJump();
        }
    }

    private void release() {
        if (!holding) return;
        holding = false;
        game.releaseJump();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                press((event.getX() - left) / scale, (event.getY() - top) / scale);
                return true;
            case MotionEvent.ACTION_UP:
                release();
                performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                release();
                return true;
            default:
                return true;
        }
    }

    @Override public boolean performClick() {
        return super.performClick();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (!isAction(keyCode)) return super.onKeyDown(keyCode, event);
        if (event.getRepeatCount() == 0) press(-1, -1);
        return true;
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (!isAction(keyCode)) return super.onKeyUp(keyCode, event);
        release();
        return true;
    }

    private static boolean isAction(int key) {
        return key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_SPACE
            || key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_ENTER;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();
        canvas.translate(left, top);
        canvas.scale(scale, scale);
        canvas.clipRect(0, 0, game.width, HEIGHT);
        if (intro && introElapsed <= 0) {
            drawOverlay(canvas, Overlay.INTRO);
        } else {
            boolean dead = game.mode == Runner.Mode.DEAD;
            canvas.save();
            if (dead) effects.shakeWorld(canvas, game.deathTime);
            world(canvas);
            canvas.restore();
            if (dead) effects.drawImpact(canvas, game.width, HEIGHT, game.deathTime);
            switch (game.mode) {
                case TITLE:
                    if (creditsProgress < 0.5) drawDithered(canvas, Overlay.TITLE, 1 - 2 * creditsProgress);
                    else if (creditsProgress > 0.5) drawDithered(canvas, Overlay.CREDITS, 2 * creditsProgress - 1);
                    break;
                case ENTERING:
                    drawDithered(canvas, Overlay.TITLE, 1 - game.time / TITLE_DITHER_TIME);
                    break;
                case RUNNING:
                    drawHud(canvas);
                    break;
                case DEAD:
                    if (result) drawDithered(canvas, Overlay.RESULT, (game.deathTime - resultDelay()) / RESULT_DITHER_TIME);
                    break;
            }
            if (intro) drawDithered(canvas, Overlay.INTRO, 1 - introElapsed / INTRO_DITHER_TIME);
            if (returnElapsed >= 0) effects.drawReturnWipe(canvas, game.width, HEIGHT, returnElapsed);
        }
        canvas.restore();
    }

    private void drawDithered(Canvas canvas, Overlay layer, double visibility) {
        int level = ScreenEffects.ditherLevel(visibility);
        if (level == 0) return;
        if (level == ScreenEffects.DITHER_LEVELS) {
            drawOverlay(canvas, layer);
        } else {
            drawOverlay(effects.beginOverlay(game.width, HEIGHT), layer);
            effects.drawOverlay(canvas, level, pixels);
        }
    }

    private void drawOverlay(Canvas canvas, Overlay layer) {
        switch (layer) {
            case INTRO:
                canvas.drawColor(Color.BLACK);
                logo(canvas, 110);
                text(canvas, "Tap to start", game.width / 2f, 257, 22, CREAM);
                break;
            case TITLE:
                drawTitle(canvas);
                break;
            case CREDITS:
                drawCredits(canvas);
                break;
            case RESULT:
                drawResult(canvas);
                break;
        }
    }

    private void world(Canvas canvas) {
        int camera = (int) Math.floor(game.camera);
        double animation = game.time + game.deathTime;
        layer(canvas, art.get("sky"), 0);
        layer(canvas, art.get("mountains"), game.camera * 0.13);
        layer(canvas, art.get("clouds"), game.camera * 0.24 + cloudDrift);
        layer(canvas, art.get("trees"), game.camera * 0.53);
        for (int i = 0; i < game.terrain.platforms.size(); i++) {
            Platform platform = game.terrain.platforms.get(i);
            if (platform.bee != null && platform.bee.x >= camera - 24 && platform.bee.x <= camera + game.width + 24) {
                pose(canvas, game.beePose(platform, animation, drawing), camera);
            }
        }
        for (int i = 0; i < game.terrain.platforms.size(); i++) {
            Platform platform = game.terrain.platforms.get(i);
            if (platform.end < camera - TILE || platform.x > camera + game.width + TILE) continue;
            drawGround(canvas, platform, camera);
            drawObjects(canvas, platform, camera, animation);
        }
        if (game.mode != Runner.Mode.TITLE) pose(canvas, game.playerPose(drawing), camera);
    }

    private void layer(Canvas canvas, Bitmap image, double position) {
        int width = image.getWidth();
        int offset = (int) Math.floor(position) % width;
        for (int x = -offset; x < game.width; x += width) {
            canvas.drawBitmap(image, x, HEIGHT - image.getHeight(), pixels);
        }
    }

    private void drawGround(Canvas canvas, Platform platform, int camera) {
        int first = Math.max(platform.x, camera / TILE * TILE - TILE);
        int last = Math.min(platform.end, camera + game.width + TILE);
        Bitmap[] strips = ground[(platform.y - Terrain.HIGHEST) / TILE];
        for (int x = first; x < last; x += TILE) {
            int column = x == platform.x ? 0 : x == platform.end - TILE ? 2 : 1;
            canvas.drawBitmap(strips[column], x - camera, platform.y, pixels);
        }
    }

    private void drawObjects(Canvas canvas, Platform platform, int camera, double animation) {
        Bitmap bushes = art.get("bushes");
        for (int i = 0; i < platform.bushes.size(); i++) {
            Bush bush = platform.bushes.get(i);
            if (bush.x < camera - 32 || bush.x > camera + game.width) continue;
            int width = bush.big ? 32 : 16;
            int sx = (bush.big ? 32 : 0) + bush.variant * width;
            sprite(canvas, bushes, sx, bush.flower * 32, width, 32, bush.x - camera, platform.y - 32);
        }
        if (platform.pad != null) {
            int x = platform.pad.x - camera;
            int y = platform.y - 31;
            if (x > -32 && x < game.width + 16) {
                sprite(canvas, art.get("signs"), 0, 0, 48, 32, x - TILE, y);
                sprite(canvas, art.get(platform.pad.used < 0 ? "pad" : "sprung"),
                    game.padFrame(platform.pad) * TILE, 0, TILE, 32, x, y);
            }
        }
        if (platform.spikeHeight > 0) pose(canvas, game.spikePose(platform, drawing), camera);
        if (platform.boar != null) pose(canvas, game.boarPose(platform, animation, drawing), camera);
    }

    private void pose(Canvas canvas, Pose pose, int camera) {
        int x = pose.x - camera;
        if (x + pose.frame.width < 0 || x > game.width) return;
        if (pose.flipped) {
            canvas.save();
            canvas.translate(x + pose.frame.width, pose.y);
            canvas.scale(-1, 1);
            sprite(canvas, art.get(pose.frame.sheet), pose.frame.sx, pose.frame.sy,
                pose.frame.width, pose.frame.height, 0, 0);
            canvas.restore();
        } else {
            sprite(canvas, art.get(pose.frame.sheet), pose.frame.sx, pose.frame.sy,
                pose.frame.width, pose.frame.height, x, pose.y);
        }
    }

    private void sprite(Canvas canvas, Bitmap image, int sx, int sy, int width, int height, int x, int y) {
        source.set(sx, sy, sx + width, sy + height);
        target.set(x, y, x + width, y + height);
        canvas.drawBitmap(image, source, target, pixels);
    }

    private void logo(Canvas canvas, int y) {
        Bitmap logo = art.get("logo");
        canvas.drawBitmap(logo, (game.width - logo.getWidth()) / 2, y, pixels);
    }

    private void drawTitle(Canvas canvas) {
        logo(canvas, 29);
        button(canvas, "Music: " + (audio.musicOn ? "ON" : "OFF"), 10, 10, 119, 40);
        button(canvas, "Sound: " + (audio.soundOn ? "ON" : "OFF"), 10, 46, 119, 76);
        button(canvas, "Credits", game.width - 110, 10, game.width - 10, 40);
        text(canvas, "Start Dashin'", game.width / 2f, 207, 23, CREAM);
    }

    private void drawCredits(Canvas canvas) {
        float center = game.width / 2f;
        panel(canvas, center - 192, 113, center + 192, 234);
        text(canvas, "All Sprites are made by Pixivic/Jovic", center, 135, 15, CREAM);
        text(canvas, "Music Used:", center, 163, 16, CREAM);
        text(canvas, "Kevin MacLeod - Pixelland", center, 186, 16, CREAM);
        text(canvas, "Jeremy Blake - Powerup!", center, 208, 16, CREAM);
    }

    private void drawResult(Canvas canvas) {
        ink.setColor(0xb0091417);
        canvas.drawRect(0, 0, game.width, HEIGHT, ink);
        float center = game.width / 2f;
        text(canvas, "U DED", center, 143, 46, 0xffff6759);
        text(canvas, "Score " + game.score(), center, 187, 24, GOLD);
        text(canvas, "GG", center, 221, 23, CREAM);
    }

    private void drawHud(Canvas canvas) {
        text(canvas, "Score", game.width / 2f, 12, 13, CREAM);
        text(canvas, Integer.toString(game.score()), game.width / 2f, 30, 23, CREAM);
        double elapsed = game.time - breathStart;
        if (breathStart < 0 || elapsed < 0) return;
        int letters = Math.min(BREATH.length(), 1 + (int) (elapsed / 0.06));
        double erase = elapsed - (BREATH.length() - 1) * 0.06 - 0.65;
        if (erase >= 0) letters = Math.max(0, BREATH.length() - 1 - (int) (erase / 0.045));
        if (letters > 0) {
            float x = (float) Terrain.clamp(game.player.x - game.camera + 4.5, 84, game.width - 84);
            text(canvas, BREATH.substring(0, letters), x, (float) game.player.feet - 56, 12, CREAM);
        }
    }

    private void button(Canvas canvas, String label, float left, float top, float right, float bottom) {
        panel(canvas, left, top, right, bottom);
        text(canvas, label, (left + right) / 2, top + 7, 15, CREAM);
    }

    private void panel(Canvas canvas, float l, float t, float r, float b) {
        ink.setColor(0xaf000000);
        corner.reset();
        corner.moveTo(l + 4, t);
        corner.lineTo(r - 4, t);
        corner.lineTo(r - 4, t + 2);
        corner.lineTo(r, t + 2);
        corner.lineTo(r, b - 2);
        corner.lineTo(r - 4, b - 2);
        corner.lineTo(r - 4, b);
        corner.lineTo(l + 4, b);
        corner.lineTo(l + 4, b - 2);
        corner.lineTo(l, b - 2);
        corner.lineTo(l, t + 2);
        corner.lineTo(l + 4, t + 2);
        corner.close();
        canvas.drawPath(corner, ink);
    }

    private void text(Canvas canvas, String text, float x, float y, float size, int color) {
        type.setTypeface(font);
        type.setTextSize(size);
        float baseline = y - type.ascent();
        type.setColor(Color.BLACK);
        type.setStyle(Paint.Style.STROKE);
        type.setStrokeWidth(size * 0.19f);
        canvas.drawText(text, x, baseline, type);
        type.setColor(color);
        type.setStyle(Paint.Style.FILL);
        canvas.drawText(text, x, baseline, type);
    }
}
