package com.pixivic.pixidash.legacy;

import android.app.Activity;
import android.graphics.Color;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import java.io.IOException;

public final class GameActivity extends Activity {
    private GameView game;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        try {
            game = new GameView(this);
            setContentView(game);
        } catch (IOException failure) {
            Log.e("PixiDash", "Game assets could not be loaded", failure);
            TextView error = new TextView(this);
            error.setGravity(Gravity.CENTER);
            error.setBackgroundColor(Color.BLACK);
            error.setTextColor(Color.WHITE);
            error.setText("Could not load PixiDash assets.\n" + failure.getMessage());
            setContentView(error);
        }
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (!focused) return;
        int flags = View.SYSTEM_UI_FLAG_LOW_PROFILE;
        if (Build.VERSION.SDK_INT >= 19) {
            flags |= View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override protected void onResume() {
        super.onResume();
        if (game != null) game.setActive(true);
    }

    @Override protected void onPause() {
        if (game != null) game.setActive(false);
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (game != null) game.close();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (game == null || !game.back()) super.onBackPressed();
    }
}
