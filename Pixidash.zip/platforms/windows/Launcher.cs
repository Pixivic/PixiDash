using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("PixiDash")]
[assembly: AssemblyProduct("PixiDash")]
[assembly: AssemblyVersion("1.0.0.0")]

internal static class Launcher
{
    [STAThread]
    private static void Main()
    {
        try
        {
            string browser = FindBrowser();
            string localData = Environment.GetEnvironmentVariable("LOCALAPPDATA");
            if (String.IsNullOrWhiteSpace(localData))
                localData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string data = Path.GetFullPath(Path.Combine(localData, "PixiDash"));
            Directory.CreateDirectory(data);
            string home = UnpackGame(data);
            string profile = Path.Combine(data, Path.GetFileNameWithoutExtension(browser) + "-profile");
            string url = new Uri(Path.Combine(home, "index.html")).AbsoluteUri;
            Process.Start(new ProcessStartInfo
            {
                FileName = browser,
                Arguments = "--no-first-run --no-default-browser-check --app=\"" + url + "\" --user-data-dir=\"" + profile + "\"",
                UseShellExecute = false
            });
        }
        catch (Exception error)
        {
            MessageBox.Show(error.Message, "PixiDash", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Environment.ExitCode = 1;
        }
    }

    private static string UnpackGame(string data)
    {
        using (Stream game = typeof(Launcher).Assembly.GetManifestResourceStream("PixiDash.game.zip"))
        {
            if (game == null)
                throw new InvalidDataException("The PixiDash game files are missing from this executable.");

            string version;
            using (SHA256 sha = SHA256.Create())
                version = BitConverter.ToString(sha.ComputeHash(game)).Replace("-", "");
            string destination = Path.Combine(data, "game-" + version);
            string entry = Path.Combine(destination, "index.html");
            if (File.Exists(entry))
                return destination;

            string staging = Path.Combine(data, "unpack-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(staging);
            try
            {
                game.Position = 0;
                using (ZipArchive archive = new ZipArchive(game, ZipArchiveMode.Read, true))
                    archive.ExtractToDirectory(staging);
                try
                {
                    Directory.Move(staging, destination);
                }
                catch (IOException)
                {
                    if (!File.Exists(entry))
                        throw;
                }
            }
            finally
            {
                if (Directory.Exists(staging))
                    Directory.Delete(staging, true);
            }
            return destination;
        }
    }

    private static string FindBrowser()
    {
        string[] roots = {
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
        };
        foreach (string browser in new[] { "chrome.exe", "msedge.exe" })
        {
            string appPath = @"\Software\Microsoft\Windows\CurrentVersion\App Paths\" + browser;
            foreach (string hive in new[] { "HKEY_CURRENT_USER", "HKEY_LOCAL_MACHINE" })
            {
                string registered = Registry.GetValue(hive + appPath, "", null) as string;
                if (!String.IsNullOrEmpty(registered) && File.Exists(registered))
                    return registered;
            }

            string folder = browser == "msedge.exe" ? @"Microsoft\Edge\Application" : @"Google\Chrome\Application";
            foreach (string root in roots)
            {
                string path = Path.Combine(root, folder, browser);
                if (File.Exists(path))
                    return path;
            }
        }
        throw new FileNotFoundException("Install Microsoft Edge or Google Chrome to run PixiDash.");
    }
}